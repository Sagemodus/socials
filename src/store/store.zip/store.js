// store.js
import { createStore } from 'vuex';
import { v4 as uuidv4 } from 'uuid';

function generateFakeUser(id, name) {
  return {
    id,
    name,
    profileImage: generateFakeProfileImage(name),
  };
}


function generateVotes(users) {
  const votes = {};

  users.forEach(user => {
    votes[user] = 10;
  });

  console.log(votes);
 
  return votes;
}

function generateFakeProfileImage(name) {
  return `https://fakeimg.pl/50x50/?text=${name[0]}&font=lobster`;
}
//Test Antwdsdfffffffzzzzzzzzzzzzzzzzzzzzzzzzzfffffffffffffffffffffffffsssssssssssssssssssssssssssssssssssssssssssssssort
function generateReplies(count, userId, userName, users) {
  const replies = [];
  for (let i = 0; i < count; i++) {
    const id = uuidv4();
    const newReply = {
      id,
      text: `hallo ${i + 1}ed diam voluptua...`,
      author: generateFakeUser(userId, userName),
      votes: generateVotes(users), // Hinzufügen von Votes
    };
    replies.push(newReply);
  }
  return replies;
}

function generateComments(count, users) {
  const comments = [];
  for (let i = 0; i < count; i++) {
    const id = uuidv4();
    const authorId = 2; // Ersetzen Sie dies durch die tatsächliche Benutzer-ID
    const newComment = {
      id,
      text: `Test Kommentar ${i + 1} Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   

      Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.   
      
      Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.   
      
      Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.   
      
      Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis.   
      
      At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, At accusam aliquyam diam diam dolore dolores duo eirmod eos erat, et nonumy sed tempor et et invidunt justo labore Stet clita ea et gubergren, kasd magna no rebum. sanctus sea sed takimata ut vero voluptua. est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur`,
      author: {
        ...users.find((user) => user.id === authorId),
        profileImage: generateFakeProfileImage(users[1].name)
      },
      replies: generateReplies(3, 1, 'John Doe', users),
      votes: {}, // Hinzufügen von Votes
    };
    comments.push(newComment);
  }
  return comments;
}

function generateTopics(count, users) {
  const topics = [];
  for (let i = 0; i < count; i++) {
    const id = uuidv4();
    const newTopic = {
      id,
      image: `https://fakeimg.pl/250x100/?text=Thema${id}&font=lobster`,
      title: `Fakes Thema ${id}`,
      text: `Dies ist eine Beschreibung...`,
      comments: generateComments(3, users),
      likes: {
        '-4': Math.floor(Math.random() * 100),
        '-3': Math.floor(Math.random() * 100),
        '-2': Math.floor(Math.random() * 100),
        '-1': Math.floor(Math.random() * 100),
        '1': Math.floor(Math.random() * 100),
        '2': Math.floor(Math.random() * 100),
        '3': Math.floor(Math.random() * 100),
        '4': Math.floor(Math.random() * 100),
      },
    };
    topics.push(newTopic);
  }
  return topics;
}

export default createStore({
  state() {
    const users = [
      {
        id: 1,
        name: 'Dejan Pantos',
        profileImage: generateFakeProfileImage('Dejan Pantos'),
        party: '-3',
  
      },
      {
        id: 2,
        name: 'Lionel Messi',
        profileImage: generateFakeProfileImage('Lionel Messi'),
        party: '-2',
  
      },
    ];

    return {
      topics: generateTopics(10, users),
      users,
      currentUser: users[0],
      userLikes: {},
    };
  },
  mutations: {
    UPVOTE_COMMENT(state, { comment, userId }) {
      if (!comment.votes) {
        comment.votes = {};
      }
      comment.votes[userId] = 1; // 1 steht für upvote
    },
    DOWNVOTE_COMMENT(state, { comment, userId }) {
      if (!comment.votes) {
        comment.votes = {};
      }
      comment.votes[userId] = -1; // -1 steht für downvote
    },
    REMOVE_UPVOTE_COMMENT(state, { comment, userId }) {
      if (comment.votes && comment.votes[userId] === 1) {
        delete comment.votes[userId];
      }
    },
    REMOVE_DOWNVOTE_COMMENT(state, { comment, userId }) {
      if (comment.votes && comment.votes[userId] === -1) {
        delete comment.votes[userId];
      }
    },

    TOGGLE_LIKE(state, { topicId, group, userId }) {
      const topic = state.topics.find(topic => topic.id === topicId);
      if (topic) {
        if (!state.userLikes[userId]) {
          state.userLikes[userId] = {};
        }
  
        // Überprüfen, ob der Benutzer bereits für diesen Beitrag in dieser Gruppe gestimmt hat
        if (state.userLikes[userId][topicId] === group) {
          // Wenn ja, entfernen Sie die Stimmabgabe
          topic.likes[group] = topic.likes[group] > 0 ? topic.likes[group] - 1 : 0;
          delete state.userLikes[userId][topicId];
        } else {
          // Wenn nicht, fügen Sie die Stimmabgabe hinzu
          topic.likes[group] = topic.likes[group] ? topic.likes[group] + 1 : 1;
          state.userLikes[userId][topicId] = group;
        }
      }
    },




    ADD_COMMENT_TO_TOPIC(state, { topicId, comment }) {
      const topic = state.topics.find((topic) => topic.id === topicId);
      if (topic) {
        topic.comments.push(comment);
      }
    },
    ADD_REPLY_TO_COMMENT(state, { commentId, reply }) {
      function searchReplies(replies) {
        for (const reply of replies) {
          if (reply.id === commentId) {
            return reply;
          }
          if (reply.replies) {
            const foundReply = searchReplies(reply.replies);
            if (foundReply) {
              return foundReply;
            }
          }
        }
        return null;
      }

      for (const topic of state.topics) {
        for (const comment of topic.comments) {
          if (comment.id === commentId) {
            if (!comment.replies) {
              comment.replies = [];
            }
            comment.replies.push(reply);
            return;
          }
          if (comment.replies) {
            const foundComment = searchReplies(comment.replies);
            if (foundComment) {
              if (!foundComment.replies) {
                foundComment.replies = [];
              }
              foundComment.replies.push(reply);
              return;
            }
          }
        }
      }
    },
    ADD_COMMENTS_TO_TOPIC(state, { topicId, comments }) {
      const topic = state.topics.find((topic) => topic.id === topicId);
      if (topic) {
        topic.comments.push(...comments);
      }
    },
  },
  actions: {

    upvoteComment(context, { commentId }) {
      const userId = context.state.currentUser.id;
      const comment = context.getters.getCommentById(commentId);
      context.commit('UPVOTE_COMMENT', { comment, userId });
    },
    downvoteComment(context, { commentId }) {
      const userId = context.state.currentUser.id;
      const comment = context.getters.getCommentById(commentId);
      context.commit('DOWNVOTE_COMMENT', { comment, userId });
    },
    removeUpvoteComment(context, { commentId }) {
      const userId = context.state.currentUser.id;
      const comment = context.getters.getCommentById(commentId);
      if (comment && comment.votes && comment.votes[userId] === 1) {
        context.commit('REMOVE_UPVOTE_COMMENT', { comment, userId });
      }
    },
    removeDownvoteComment(context, { commentId }) {
      const userId = context.state.currentUser.id;
      const comment = context.getters.getCommentById(commentId);
      if (comment && comment.votes && comment.votes[userId] === -1) {
        context.commit('REMOVE_DOWNVOTE_COMMENT', { comment, userId });
      }
    },

    addCommentToTopic({ commit }, { topicId, comment }) {
      comment.id = uuidv4();
      commit('ADD_COMMENT_TO_TOPIC', { topicId, comment });
    },
    addReplyToComment({ commit }, { commentId, reply }) {
      commit('ADD_REPLY_TO_COMMENT', { commentId, reply });
    },
    fetchComments({ state, commit }) {
      if (state.topics.every((topic) => topic.comments.length > 0)) {
        return;
      }

      for (const topic of state.topics) {
        if (topic.comments.length === 0) {
          const comments = generateComments(3, state.users);
          commit('ADD_COMMENTS_TO_TOPIC', { topicId: topic.id, comments });
        }
      }
    },
  },
  getters: {

    hasLikedComment: (state) => (commentId) => {
      for (const topic of state.topics) {
        const comment = topic.comments.find((c) => c.id === commentId);
        if (comment && comment.votes) {
          return Object.values(comment.votes).some((vote) => vote === 1);
        }
      }
      return false;
    },
  
    hasDislikedComment: (state) => (commentId) => {
      for (const topic of state.topics) {
        const comment = topic.comments.find((c) => c.id === commentId);
        if (comment && comment.votes) {
          return Object.values(comment.votes).some((vote) => vote === -1);
        }
      }
      return false;
    },



    getTopicById: (state) => (id) => {
      return state.topics.find((topic) => topic.id === id);
    },
    getUserProfile: (state) => {
      return state.users[0];
    },
  
      getCommentById: (state) => (commentId) => {
        // Zuerst in den Kommentaren suchen
        for (const topic of state.topics) {
          for (const comment of topic.comments) {
            if (comment.id === commentId) {
              return comment;
            }
          }
        }
    
        // Wenn nicht in den Kommentaren gefunden, in den Antworten suchen
        function searchReplies(replies) {
          for (const reply of replies) {
            if (reply.id === commentId) {
              return reply;
            }
            if (reply.replies) {
              const foundReply = searchReplies(reply.replies);
              if (foundReply) {
                return foundReply;
              }
            }
          }
          return null;
        }
    
        for (const topic of state.topics) {
          for (const comment of topic.comments) {
            if (comment.replies) {
              const foundComment = searchReplies(comment.replies);
              if (foundComment) {
                return foundComment;
              }
            }
          }
        }
    
        console.log("getCommentById: Comment not found!");
        return null;
      
    },
    getAllComments: (state) => {
      let allComments = [];
      for (let topic of state.topics) {
        allComments = allComments.concat(topic.comments);
      }
      return allComments;
    },

    getUserParty(state) {
      return state.currentUser.party;
    },

  },
});
